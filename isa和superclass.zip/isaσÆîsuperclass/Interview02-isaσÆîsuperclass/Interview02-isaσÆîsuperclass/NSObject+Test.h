//
//  NSObject+Test.h
//  Interview02-isa和superclass
//
//  Created by MJ Lee on 2018/4/15.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Test)

+ (void)test;

@end
