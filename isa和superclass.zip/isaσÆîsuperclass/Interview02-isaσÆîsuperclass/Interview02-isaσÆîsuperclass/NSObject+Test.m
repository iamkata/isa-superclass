//
//  NSObject+Test.m
//  Interview02-isa和superclass
//
//  Created by MJ Lee on 2018/4/15.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "NSObject+Test.h"

@implementation NSObject (Test)

//+ (void)test
//{
//    NSLog(@"+[NSObject test] - %p", self);
//}
//如果把上面代码注释掉:执行[MJPerson test];[NSObject test];调用的都是下面的方法,为什么这样调用,看类方法调用轨迹图

- (void)test
{
    NSLog(@"-[NSObject test] - %p", self);
}

@end


//2019-11-22 18:20:03.757563+0800 Interview02-isa和superclass[37256:3248068] [MJPerson class] - 0x1000011e0
//2019-11-22 18:20:03.757736+0800 Interview02-isa和superclass[37256:3248068] [NSObject class] - 0x7fff97e99140
//2019-11-22 18:20:03.757746+0800 Interview02-isa和superclass[37256:3248068] -[NSObject test] - 0x1000011e0
//2019-11-22 18:20:03.757752+0800 Interview02-isa和superclass[37256:3248068] -[NSObject test] - 0x7fff97e99140
