//
//  main.m
//  Interview03-isa
//
//  Created by MJ Lee on 2018/4/15.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

// MJPerson
@interface MJPerson : NSObject <NSCopying>
{
@public
    int _age;
}
@property (nonatomic, assign) int no;
- (void)personInstanceMethod;
+ (void)personClassMethod;
@end

@implementation MJPerson

- (void)test
{
    
}

- (void)personInstanceMethod
{
    
}
+ (void)personClassMethod
{
    
}
- (id)copyWithZone:(NSZone *)zone
{
    return nil;
}
@end

// MJStudent
@interface MJStudent : MJPerson <NSCoding>
{
@public
    int _weight;
}
@property (nonatomic, assign) int height;
- (void)studentInstanceMethod;
+ (void)studentClassMethod;
@end

@implementation MJStudent
- (void)test
{
    
}
- (void)studentInstanceMethod
{
    
}
+ (void)studentClassMethod
{
    
}
- (id)initWithCoder:(NSCoder *)aDecoder
{
    return nil;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    
}
@end

struct mj_objc_class {
    Class isa;
    Class superclass;
};

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // MJPerson类对象的地址：0x00000001000014c8
        // isa & ISA_MASK  =  0x00000001000014c8
        
        // MJPerson实例对象的isa：0x001d8001000014c9
        //在64位以前MJPerson实例对象的isa储存的地址就是MJPerson类对象的地址,64位以后MJPerson实例对象的isa和ISA_MASK进行位运算之后才是MJPerson类对象的地址(isa & ISA_MASK = MJPerson类对象的地址)
        //实例对象的isa & ISA_MASK 之后才等于 类对象
        //同理类对象的isa & ISA_MASK 之后才等于元类对象
        
        //supreclass里面存的直接是父类的地址,不存在这种情况
//        struct mj_objc_class *personClass = (__bridge struct mj_objc_class *)([MJPerson class]);
//
//        struct mj_objc_class *studentClass = (__bridge struct mj_objc_class *)([MJStudent class]);
//
//        NSLog(@"1111");
        
        MJPerson *person = [[MJPerson alloc] init];

        Class personClass = [MJPerson class];

        struct mj_objc_class *personClass2 = (__bridge struct mj_objc_class *)(personClass);

        Class personMetaClass = object_getClass(personClass);

        NSLog(@"%p %p %p", person, personClass, personMetaClass);
        //0x100603ac0 0x1000014d0 0x1000014a8

        //(lldb) p/x (long)person->isa    (long) $0 = 0x001d8001000014d1
        //类对象地址:0x00000001000014d0
        //元类对象地址: 0x00000001000014a8
    }
    return 0;
}
